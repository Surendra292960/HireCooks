package com.test.sample.hirecooks.Adapter.Home;

/**
 * Created by zero on 3/11/15.
 */
public class FeedProperties {


    private String title;
    private int thumbnail;


    public String getTitle() {
        return title;
    }


    public void setTitle(String title)

    {
        this.title = title;
    }


    public int getThumbnail() {

        return thumbnail;
    }


    public void setThumbnail(int thumbnail) {

        this.thumbnail = thumbnail;
    }
}
