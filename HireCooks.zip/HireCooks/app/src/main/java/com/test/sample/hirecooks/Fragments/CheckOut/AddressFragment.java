package com.test.sample.hirecooks.Fragments.CheckOut;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.libraries.places.api.Places;
import com.google.gson.Gson;
import com.test.sample.hirecooks.Activity.Home.MainActivity;
import com.test.sample.hirecooks.ApiServiceCall.ApiClient;
import com.test.sample.hirecooks.BaseActivity;
import com.test.sample.hirecooks.MapLocation;
import com.test.sample.hirecooks.Models.Cart.Cart;
import com.test.sample.hirecooks.Models.MapLocationResponse.Map;
import com.test.sample.hirecooks.Models.MapLocationResponse.Result;
import com.test.sample.hirecooks.Models.Order.Order;
import com.test.sample.hirecooks.Models.Order.Results;
import com.test.sample.hirecooks.Models.TokenResponse.TokenResult;
import com.test.sample.hirecooks.Models.users.User;
import com.test.sample.hirecooks.R;
import com.test.sample.hirecooks.RoomDatabase.LocalStorage.LocalStorage;
import com.test.sample.hirecooks.Utils.Constants;
import com.test.sample.hirecooks.Utils.OnClickRateLimitedDecoratedListener;
import com.test.sample.hirecooks.Utils.ProgressBarUtil;
import com.test.sample.hirecooks.Utils.SharedPrefManager;
import com.test.sample.hirecooks.Utils.SharedPrefToken;
import com.test.sample.hirecooks.WebApis.MapApi;
import com.test.sample.hirecooks.WebApis.NotificationApi;
import com.test.sample.hirecooks.WebApis.OrderApi;
import com.test.sample.hirecooks.WebApis.UserApi;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.facebook.accountkit.internal.AccountKitController.getApplicationContext;

public class AddressFragment extends Fragment {
    Context context;
    EditText editTextAddress,editTextDeliveryTime;
    TextView editTextHirecookMoney,editTextPromo,editTextSubTotal,editTextDeliveryCharge,editTextGrandTotal,editTextPayableAmount,editTextCashOnDelivery;
    private ProgressBarUtil progressBarUtil;
    GoogleMap mMap;
    List<Cart> cartList = new ArrayList<>();
    LocalStorage localStorage;
    Gson gson;
    Double mTotal, mDeliveryCharges, mTotalAmount;
    String id,orderNo;
    private User user;
    private Map maps;
    private RadioGroup radioPromo;
    private OrderApi mService;
    private int discount = 0, discountPercentage = 0, displayrate = 0;

    public AddressFragment(){

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_address, container, false);
        context = container.getContext();
        progressBarUtil = new ProgressBarUtil(getActivity());
        radioPromo = v.findViewById(R.id.radioPromo);
        editTextAddress = v.findViewById(R.id.editTextAddress);
        editTextDeliveryTime = v.findViewById(R.id.editTextDeliveryTime);
        editTextSubTotal = v.findViewById(R.id.editTextSubTotal);
        editTextPromo = v.findViewById(R.id.editTextPromo);
        editTextHirecookMoney = v.findViewById(R.id.editTextHirecookMoney);
        editTextDeliveryCharge = v.findViewById(R.id.editTextDeliveryCharge);
        editTextGrandTotal = v.findViewById(R.id.editTextGrandTotal);
        editTextPayableAmount = v.findViewById(R.id.editTextPayableAmount);
        editTextCashOnDelivery = v.findViewById(R.id.editTextCashOnDelivery);
        user = SharedPrefManager.getInstance(getActivity()).getUser();

        Random rnd = new Random();
        orderNo = String.valueOf(100000 + rnd.nextInt(900000));

        localStorage = new LocalStorage(getContext());
        gson = new Gson();
        cartList = ((BaseActivity) getActivity()).getCartList();

        mTotal = ((BaseActivity) getActivity()).getTotalPrice();
        mDeliveryCharges = 0.0;
        mTotalAmount = mTotal + mDeliveryCharges;
        editTextSubTotal.setText("\u20B9 "+mTotal + "");
        editTextPromo.setText("- \u20B9 "+00 + "");
        editTextHirecookMoney.setText("- \u20B9 "+00 + "");
        editTextDeliveryCharge.setText("+ \u20B9 "+mDeliveryCharges + "");
        editTextGrandTotal.setText("\u20B9 "+mTotalAmount + "");
        editTextPayableAmount.setText("Payable Amount "+"\u20B9 "+mTotalAmount + "");

        editTextAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(),MapLocation.class));
            }
        });

        editTextCashOnDelivery.setOnClickListener(new OnClickRateLimitedDecoratedListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(maps!=null){
                    if(cartList!=null&&cartList.size()!=0){
                        for(Cart cart:cartList){
                            Order order = new Order();
                            order.setOrderId(orderNo);
                            order.setProductName(cart.getName());
                            order.setProductSellRate(cart.getSellRate());
                            order.setProductDisplayRate(cart.getDisplayRate());
                            discount = (order.getProductDisplayRate() - order.getProductSellRate());
                            displayrate = (order.getProductDisplayRate());
                            discountPercentage = (discount * 100 / displayrate);
                            order.setProductDiscount(discountPercentage);
                            order.setProductQuantity(cart.getItemQuantity());
                            order.setProductTotalAmount(cart.getTotalAmount());
                            order.setOrderStatus("Pending");
                            order.setProductImage(cart.getLink());
                            order.setFirmId(cart.getFirm_id());
                            order.setUserId(user.getId());
                            order.setPaymentMethod("COD");
                            order.setOrderPlaceId(maps.getPlaceId());
                            order.setOrderLatitude(maps.getLatitude());
                            order.setOrderLongitude(maps.getLongitude());
                            order.setOrderAddress(maps.getAddress());
                            order.setOrderPincode(maps.getPincode());
                            if(cart.getWeight()==null){
                                order.setOrderWeight("null");
                            }else{
                                order.setOrderWeight(cart.getWeight());
                            }
                            if (SharedPrefManager.getInstance(getActivity()).isLoggedIn()) {
                                if(order.getOrderId()!=null&&order.getProductName()!=null&&order.getProductSellRate()!=0&&order.getProductDisplayRate()!=0&&order.getProductQuantity()!=0&&order.getProductTotalAmount()!=0&&order.getOrderStatus()!=null&&order.getProductImage()!=null&&order.getFirmId()!=null&&order.getUserId()!=0&&order.getOrderWeight()!=null&&order.getPaymentMethod()!=null&&order.getOrderPlaceId()!=null&&order.getOrderLatitude()!=null&&order.getOrderLongitude()!=null&&order.getOrderAddress()!=null&&order.getOrderPincode()!=0){
                                    placeOrder(order);
                                }else{
                                    Toast.makeText(getActivity(),"These Item can`t be placed please remove item and try again",Toast.LENGTH_LONG).show();
                                }
                            }else{
                                Toast.makeText(getActivity(),"Please Login First",Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }else{
                    Toast.makeText(getActivity(),"Please Select Address",Toast.LENGTH_LONG).show();
                }
            }
        },5000));

       /* editTextCashOnDelivery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(maps!=null){
                    if(cartList!=null&&cartList.size()!=0){
                        for(Cart cart:cartList){
                            Order order = new Order();
                            order.setOrderId(orderNo);
                            order.setProductName(cart.getName());
                            order.setProductSellRate(cart.getSellRate());
                            order.setProductDisplayRate(cart.getDisplayRate());
                            discount = (order.getProductDisplayRate() - order.getProductSellRate());
                            displayrate = (order.getProductDisplayRate());
                            discountPercentage = (discount * 100 / displayrate);
                            order.setProductDiscount(discountPercentage);
                            order.setProductQuantity(cart.getItemQuantity());
                            order.setProductTotalAmount(cart.getTotalAmount());
                            order.setOrderStatus("Pending");
                            order.setProductImage(cart.getLink());
                            order.setFirmId(cart.getFirm_id());
                            order.setUserId(user.getId());
                            order.setPaymentMethod("COD");
                            order.setPlaceId(maps.getPlaceId());
                            order.setLatitude(maps.getLatitude());
                            order.setLongitude(maps.getLongitude());
                            order.setOrderAddress(maps.getAddress());
                            order.setPincode(maps.getPincode());
                            if(cart.getWeight()==null){
                                order.setWeight("null");
                            }else{
                                order.setWeight(cart.getWeight());
                            }
                            if (SharedPrefManager.getInstance(getActivity()).isLoggedIn()) {
                                if(order.getOrderId()!=null&&order.getProductName()!=null&&order.getProductSellRate()!=0&&order.getProductDisplayRate()!=0&&order.getProductQuantity()!=0&&order.getProductTotalAmount()!=0&&order.getOrderStatus()!=null&&order.getProductImage()!=null&&order.getFirmId()!=null&&order.getUserId()!=0&&order.getWeight()!=null&&order.getPaymentMethod()!=null&&order.getPlaceId()!=null&&order.getLatitude()!=null&&order.getLongitude()!=null&&order.getOrderAddress()!=null&&order.getPincode()!=0){
                                    placeOrder(order);
                                }else{
                                    Toast.makeText(getActivity(),"These Item can`t be placed please remove item and try again",Toast.LENGTH_LONG).show();
                                }
                            }else{
                                Toast.makeText(getActivity(),"Please Login First",Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }else{
                    Toast.makeText(getActivity(),"Please Select Address",Toast.LENGTH_LONG).show();
                }
            }
        });*/

        getMapDetails();
        getDateAndTime();
        return v;
    }

    private void placeOrder(Order order) {
        mService = ApiClient.getClient().create(OrderApi.class);
        Call<Results> call = mService.submitOrder(order.getOrderId(),order.getProductName(),order.getProductSellRate(),order.getProductDisplayRate(),order.getProductDiscount(),order.getProductQuantity(),order.getProductTotalAmount(),order.getOrderStatus(),order.getProductImage(),order.getFirmId(),order.getUserId(),order.getOrderWeight(),order.getPaymentMethod(),order.getOrderPlaceId(),order.getOrderLatitude(),order.getOrderLongitude(),order.getOrderAddress(),order.getOrderPincode());
        call.enqueue(new Callback<Results>() {
            @Override
            public void onResponse(Call<Results> call, Response<Results> response) {
                if (response.code() == 200 &&response.body().getError()==false) {
                    Toast.makeText(getActivity(),response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    localStorage.deleteCart();
                    getTokenFromServer(order.getFirmId(),order.getUserId());
                    getActivity().finish();
                    startActivity(new Intent(getActivity(), MainActivity.class));
                } else {
                    Toast.makeText(getActivity(),response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Results> call, Throwable t) {
                Toast.makeText(getActivity(),R.string.error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getTokenFromServer(String firm_id, int userId) {
        UserApi mService =  ApiClient.getClient().create(UserApi.class);
        Call<TokenResult> call1 = mService.getTokenByFirmId(firm_id,userId);
        call1.enqueue(new Callback<TokenResult>() {
            @Override
            public void onResponse(Call<TokenResult> call, Response<TokenResult> response) {
                int statusCode = response.code();
                if(statusCode==200&&response.body().getError()==false) {
                    progressBarUtil.hideProgress();
                    TokenResult tokenResult = response.body();
                    sendNotification(firm_id,tokenResult.getToken().getToken());
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                    System.out.println("Suree Token  "+SharedPrefToken.getInstance(getApplicationContext()).getTokens().getToken());
                }
                else{
                    Toast.makeText(getApplicationContext(), R.string.failed_due_to+response.code(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<TokenResult> call, Throwable t) {
                progressBarUtil.hideProgress();
                Toast.makeText(getApplicationContext(), R.string.error+t.getMessage(), Toast.LENGTH_LONG).show();
                System.out.println("Suree: "+t.getMessage());
            }
        });
    }

    private void sendNotification(String firmId, String token) {
        NotificationApi mService = ApiClient.getClient().create(NotificationApi.class);
        Call<String> call = mService.sendNotification(token,firmId);
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                if (response.code() == 200 ) {
                    localStorage.deleteCart();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Toast.makeText(getActivity(),R.string.error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getDateAndTime() {
        Calendar c = Calendar.getInstance();

        int seconds = c.get(Calendar.SECOND);
        int minutes = c.get(Calendar.MINUTE);
        int hour = c.get(Calendar.HOUR_OF_DAY);

        String time = hour+3 + ":" + minutes + ":" + seconds;

        int day = c.get(Calendar.DAY_OF_MONTH);
        int month = c.get(Calendar.MONTH);
        int year = c.get(Calendar.YEAR);
        String date = day + "-" + month + "-" + year;

        editTextDeliveryTime.setText(date+"  "+time);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            if (getFragmentManager().getBackStackEntryCount() != 0) {
                getFragmentManager().popBackStack();
            }
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void onBackPressed() {
        if (getFragmentManager().getBackStackEntryCount() != 0) {
            getFragmentManager().popBackStack();
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle("Address");
        initializeViews();
    }

    private void initializeViews() {
        try {
            Places.initialize(getActivity(), Constants.locationApiKey);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void getMapDetails() {
        progressBarUtil.showProgress();
        MapApi mService = ApiClient.getClient().create(MapApi.class);
        Call<Result> call = mService.getMapDetails(user.getId());
        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                if (response.code() == 200 && response.body() != null && response.body().getMaps() != null) {
                    progressBarUtil.hideProgress();
                    try{
                        maps = response.body().getMaps();
                        editTextAddress.setText(maps.getAddress());
                        mMap.clear();
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    editTextAddress.setText(maps.getAddress());
                } else {
                    Toast.makeText(getActivity(),"Failed due to: "+response.errorBody(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {
                progressBarUtil.hideProgress();
                Toast.makeText(getActivity(),R.string.error+t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onStart() {
        getMapDetails();
        super.onStart();
    }
}
