package com.test.sample.hirecooks.Utils;

public interface OnButtonClickListener {
    void showCreateDialog();
}