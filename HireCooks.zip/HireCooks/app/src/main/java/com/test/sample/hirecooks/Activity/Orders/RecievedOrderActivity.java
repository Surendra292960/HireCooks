package com.test.sample.hirecooks.Activity.Orders;

import android.os.Build;
import android.os.Bundle;
import android.transition.Explode;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.test.sample.hirecooks.Adapter.Orders.OrdersAdapter;
import com.test.sample.hirecooks.ApiServiceCall.ApiClient;
import com.test.sample.hirecooks.Models.Order.Order;
import com.test.sample.hirecooks.Models.Order.Results;
import com.test.sample.hirecooks.Models.users.User;
import com.test.sample.hirecooks.R;
import com.test.sample.hirecooks.Utils.ProgressBarUtil;
import com.test.sample.hirecooks.Utils.SharedPrefManager;
import com.test.sample.hirecooks.WebApis.OrderApi;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RecievedOrderActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ProgressBarUtil progressBarUtil;
    private OrderApi mService;
    private User user;
    private List<Order> ordersList;
    private OrdersAdapter ordersAdapter;
    private View appRoot;
    private LinearLayout no_orders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int flags = WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_FULLSCREEN;

        getWindow().addFlags(flags);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setExitTransition(new Explode());
        }
        setContentView(R.layout.activity_recieved_order);
        Objects.requireNonNull(getSupportActionBar()).setHomeButtonEnabled(true);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Recieved Orders");
        user = SharedPrefManager.getInstance(this).getUser();
        appRoot = findViewById(R.id.appRoot);
        initViews();
        getOrders();
    }

    private void initViews() {
        progressBarUtil = new ProgressBarUtil(this);
        recyclerView = findViewById(R.id.recieved_orders_recycler);
        no_orders = findViewById(R.id.no_orders);
    }

    private void getOrders() {
        progressBarUtil.showProgress();
        mService = ApiClient.getClient().create(OrderApi.class);
        Call<Results> call = mService.getOrder();
        call.enqueue(new Callback<Results>() {
            @Override
            public void onResponse(Call<Results> call, Response<Results> response) {
                if (response.code() == 200 ) {
                    progressBarUtil.hideProgress();
                    List<Order> orders = response.body().getOrder();
                    ordersList = new ArrayList<>();
                    if(orders!=null&&orders.size()!=0){
                        for(Order order:orders){
                            if(order!=null&&order.getFirmId().equalsIgnoreCase(user.getFirmId())){
                                ordersList.add(order);
                            }
                        }
                    }
                    if(ordersList!=null&&ordersList.size()!=0){
                        recyclerView.setVisibility(View.VISIBLE);
                        no_orders.setVisibility(View.GONE);
                        Toast.makeText(RecievedOrderActivity.this,response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        ordersAdapter = new OrdersAdapter(RecievedOrderActivity.this,ordersList);
                        recyclerView.setAdapter(ordersAdapter);
                    }else{
                        recyclerView.setVisibility(View.GONE);
                        no_orders.setVisibility(View.VISIBLE);
                    }
                } else {
                    Toast.makeText(RecievedOrderActivity.this,"Failed due to: "+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Results> call, Throwable t) {
                Toast.makeText(RecievedOrderActivity.this,R.string.error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        this.finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
