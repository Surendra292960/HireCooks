package com.test.sample.hirecooks.Activity.Cart;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.squareup.picasso.Picasso;
import com.test.sample.hirecooks.Activity.CheckOut.CheckoutActivity;
import com.test.sample.hirecooks.Activity.Home.MainActivity;
import com.test.sample.hirecooks.Activity.SubCategory.SubCategoryDetails.SubCategoryDetails;
import com.test.sample.hirecooks.BaseActivity;
import com.test.sample.hirecooks.Models.Cart.Cart;
import com.test.sample.hirecooks.Models.SubCategory.Response.SubCategory;
import com.test.sample.hirecooks.R;
import com.test.sample.hirecooks.RoomDatabase.LocalStorage.LocalStorage;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CartActivity extends BaseActivity {
    private RecyclerView recyclerView;
    private TextView item_count,checkout_amount,checkout;
    private FrameLayout empty_cart_img;
    private AppCompatButton shop_now;
    private View appRoot;
    List<Cart> cartList;
    RelativeLayout bottom_anchor_layout;
    int Quantity = 0, sellRate = 0,displayRate = 0, SubTotal = 0,weight = 0;
    LocalStorage localStorage;
    Gson gson;
    CartAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        Objects.requireNonNull(getSupportActionBar()).setHomeButtonEnabled(true);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Cart");
        initViews();
        getCart();
    }

    private void initViews() {
        recyclerView = findViewById(R.id.recyclerview_cart);
        appRoot = findViewById(R.id.appRoot);
        bottom_anchor_layout = findViewById(R.id.bottom_anchor_layout);
        empty_cart_img = findViewById(R.id.empty_cart_img);
        shop_now = findViewById(R.id.shop_now);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        View view = findViewById(R.id.footerView);
        item_count =  view.findViewById(R.id.item_count);
        checkout_amount = view.findViewById(R.id.checkout_amount);
        checkout = view.findViewById(R.id.checkout);


        shop_now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(new Intent(CartActivity.this, MainActivity.class));
            }
        });
    }

    private void getCart() {
        cartList = new ArrayList<>();
        cartList = getCartList();
        if(!cartList.isEmpty()){
            bottom_anchor_layout.setVisibility(View.VISIBLE);
            checkout_amount.setText("₹  "+getTotalPrice());
            empty_cart_img.setVisibility(View.GONE);
            item_count.setText(""+cartCount());
            adapter = new CartAdapter(CartActivity.this, cartList);
            recyclerView.setAdapter(adapter);
            System.out.println("Suree wieght: "+ cartList.get(0).getWeight());
        }else{
            bottom_anchor_layout.setVisibility(View.GONE);
            empty_cart_img.setVisibility(View.VISIBLE);
        }

        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CartActivity.this, CheckoutActivity.class));
            }
        });
    }

    @Override
    protected void onRestart() {
        getCart();
        super.onRestart();
    }

    @Override
    protected void onResume() {
        getCart();
        super.onResume();
    }

    @Override
    public void onBackPressed() {
        this.finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater ( );
        menuInflater.inflate ( R.menu.clear_cart_menu , menu );
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
           this.finish();
        }else if ( id == R.id.ic_delete ) {
            AlertDialog diaBox = showDeleteDialog();
            diaBox.show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private AlertDialog showDeleteDialog() {
        AlertDialog myQuittingDialogBox = new AlertDialog.Builder(this)
                //set message, title, and icon
                .setTitle("Delete")
                .setMessage("Do you want to Delete")
                .setIcon(R.drawable.ic_delete)
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int whichButton) {
                        localStorage.deleteCart();
                        adapter.notifyDataSetChanged();
                        empty_cart_img.setVisibility(View.VISIBLE);
                       /* mState = "HIDE_MENU";*/
                        invalidateOptionsMenu();
                        dialog.dismiss();
                    }
                })
                .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .create();
        return myQuittingDialogBox;
    }

    public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {
        private Context mCtx;
        private List<Cart> cartList;

        public CartAdapter(Context mCtx, List<Cart> cartList) {
            this.mCtx = mCtx;
            this.cartList = cartList;
        }


        @Override
        public CartAdapter.CartViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(mCtx).inflate(R.layout.recyclerview_cart, parent, false);
            return new CartAdapter.CartViewHolder(view);
        }

        public void delete(int position) { //removes the row
            cartList.remove(position);
            notifyItemRemoved(position);
        }


        @Override
        public void onBindViewHolder(CartAdapter.CartViewHolder holder, int position) {
            if(cartList!=null){
                localStorage = new LocalStorage(mCtx);
                gson = new Gson();
                Cart cart = cartList.get(position);
                holder.itemName.setText(cart.getName());
                holder.itemDesc.setText(cart.getDesc());
                if(cart.getItemQuantity()>1){
                    holder.itemQuantity.setText(""+cart.getItemQuantity());
                    holder.itemTotalAmt.setText("₹ "+cart.getTotalAmount());
                }else{
                    holder.itemTotalAmt.setText("₹ "+cart.getSellRate());
                    holder.itemQuantity.setText(""+cart.getItemQuantity());
                }
                Picasso.with(mCtx).load(cart.getLink()).into(holder.itemImage);

                holder.itemAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        sellRate = cart.getSellRate();
                        displayRate = cart.getDisplayRate();
                        String count = holder.itemQuantity.getText().toString();
                        Quantity = Integer.parseInt(count);
                        if (Quantity >= 1) {
                            Quantity++;
                            holder.itemQuantity.setText(""+(Quantity));
                            for (int i = 0; i < cartList.size(); i++) {
                                if (cartList.get(i).getId()==cart.getId()&&cartList.get(i).getName().equalsIgnoreCase(cart.getName())) {
                                    SubTotal = (sellRate * Quantity);
                                    cartList.get(i).setItemQuantity(Quantity);
                                    cartList.get(i).setTotalAmount(SubTotal);
                                    String cartStr = gson.toJson(cartList);
                                    localStorage.setCart(cartStr);
                                    notifyItemChanged(position);
                                    getCart();
                                }
                            }
                        }
                    }
                });

                holder.itemRemove.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        sellRate = cart.getSellRate();
                        displayRate = cart.getDisplayRate();
                        String count = holder.itemQuantity.getText().toString();
                        Quantity = Integer.parseInt(count);
                        if (Quantity > 1) {
                            Quantity--;
                            holder.itemQuantity.setText(""+(Quantity));
                            for (int i = 0; i < cartList.size(); i++) {
                                if (cartList.get(i).getId()==cart.getId()&&cartList.get(i).getName().equalsIgnoreCase(cart.getName())) {
                                    SubTotal = (sellRate * Quantity);
                                    cartList.get(i).setItemQuantity(Quantity);
                                    cartList.get(i).setTotalAmount(SubTotal);
                                    String cartStr = gson.toJson(cartList);
                                    localStorage.setCart(cartStr);
                                    notifyItemChanged(position);
                                    getCart();
                                }
                            }
                        }
                    }
                });

                holder.itemDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        cartList.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, cartList.size());
                        Gson gson = new Gson();
                        String cartStr = gson.toJson(cartList);
                        Log.d("CART", cartStr);
                        localStorage.setCart(cartStr);
                        ((CartActivity) mCtx).updateTotalPrice();
                        getCart();
                    }
                });
            }
        }

        @Override
        public int getItemCount() {
            return cartList==null?0:cartList.size();
        }

        class CartViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
            TextView itemName, itemDesc, itemTotalAmt,itemAdd,itemRemove,itemQuantity,itemDelete;
            ImageView itemImage;

            public CartViewHolder(View itemView) {
                super(itemView);
                itemName = itemView.findViewById(R.id.item_name);
                itemDesc = itemView.findViewById(R.id.item_short_desc);
                itemTotalAmt = itemView.findViewById(R.id.total_Amount);
                itemImage = itemView.findViewById(R.id.product_thumb);
                itemAdd = itemView.findViewById(R.id.add_item);
                itemRemove = itemView.findViewById(R.id.remove_item);
                itemQuantity = itemView.findViewById(R.id.item_count);
                itemDelete = itemView.findViewById(R.id.item_delete);
                itemView.setOnClickListener(this);
            }

            @Override
            public void onClick(View view) {
                SubCategory subCategory = new SubCategory();
                for (Cart cart:cartList){
                    //subCategory.setId(cart.getId());
                    subCategory.setName(cart.getName());
                    //subCategory.setSellRate(cart.getSellRate());
                    subCategory.setDescription(cart.getDesc());
                    // subCategory.setLink(cart.getImage());
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    Intent intent = new Intent(mCtx, SubCategoryDetails.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("Cart", subCategory);
                    intent.putExtras(bundle);
                    mCtx.startActivity(intent, ActivityOptions.makeSceneTransitionAnimation((Activity) mCtx).toBundle());
                }
            }
        }
    }
}