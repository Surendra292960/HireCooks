package com.test.sample.hirecooks.Fragments;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;

import com.google.android.material.textfield.TextInputEditText;
import com.test.sample.hirecooks.ApiServiceCall.ApiClient;
import com.test.sample.hirecooks.Models.users.Result;
import com.test.sample.hirecooks.Models.users.User;
import com.test.sample.hirecooks.R;
import com.test.sample.hirecooks.Utils.Constants;
import com.test.sample.hirecooks.Utils.ProgressBarUtil;
import com.test.sample.hirecooks.Utils.SharedPrefManager;
import com.test.sample.hirecooks.WebApis.UserApi;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileFragment extends Fragment implements View.OnClickListener {
    private AppCompatButton buttonUpdate;
    private TextInputEditText editTextUsername, editTextEmail, editTextPassword,editTextPhone,
            editTextFirmId,editTextUserType;
    private RadioGroup radioGender;
    private View appRoot;
    private ProgressBarUtil progressBarUtil;

    public ProfileFragment(){

    }

    public static ProfileFragment newInstance() {
        Bundle args = new Bundle();
        ProfileFragment fragment = new ProfileFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        progressBarUtil = new ProgressBarUtil(getActivity());
        buttonUpdate = view.findViewById(R.id.buttonUpdate);
        appRoot = view.findViewById(R.id.appRoot);
        editTextUsername = view.findViewById(R.id.editTextUsername);
        editTextEmail = view.findViewById(R.id.editTextEmail);
        editTextPassword = view.findViewById(R.id.editTextPassword);
        editTextPhone = view.findViewById(R.id.editTextPhone);
        editTextUserType = view.findViewById(R.id.editTextUserType);
        editTextFirmId = view.findViewById(R.id.editTextFirmId);
        radioGender = view.findViewById(R.id.radioGender);
        buttonUpdate.setOnClickListener(this);

        User user = SharedPrefManager.getInstance(getActivity()).getUser();

        editTextUsername.setText(user.getName());
        editTextEmail.setText(user.getEmail());
        editTextPassword.setText(user.getPassword());
        editTextPhone.setText(user.getPhone());
        editTextUserType.setText(user.getUserType());
        editTextFirmId.setText(user.getFirmId());

        if (user.getGender().equalsIgnoreCase("male")) {
            radioGender.check(R.id.radioMale);
        } else {
            radioGender.check(R.id.radioFemale);
        }

        return view;
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }



    @Override
    public void onClick(View view) {
        if (view == buttonUpdate) {
            updateUser();
        }
    }

    private void updateUser() {
        progressBarUtil.showProgress();
        final RadioButton radioSex = getActivity().findViewById(radioGender.getCheckedRadioButtonId());
        String name = editTextUsername.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String phone = editTextPhone.getText().toString().trim();
        String firmId = SharedPrefManager.getInstance(getActivity()).getUser().getFirmId();
        String userType = SharedPrefManager.getInstance(getActivity()).getUser().getUserType();
        String image = null;
        String gender = radioSex.getText().toString();

        UserApi service = ApiClient.getClient().create(UserApi.class);
        User user = new User(SharedPrefManager.getInstance(getActivity()).getUser().getId(), name, email, phone, password, gender, firmId, userType);
        Call<Result> call = service.updateUser(user.getId(), user.getName(), user.getEmail(),user.getPhone(), user.getPassword(), user.getGender(), user.getFirmId(), user.getUserType());
        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                int statusCode = response.code();
                if(statusCode==200&&response.body().getError()==false){
                    progressBarUtil.hideProgress();
                    if (!response.body().getError()) {
                        Constants.CurrentUser = response.body();
                        SharedPrefManager.getInstance(getActivity()).userLogin(Constants.CurrentUser.getUser());
                        Toast.makeText(getActivity(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(getActivity(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {
                progressBarUtil.hideProgress();
                Toast.makeText(getActivity(), t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}