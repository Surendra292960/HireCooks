package com.test.sample.hirecooks.Adapter.Orders;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;
import com.test.sample.hirecooks.Models.Order.Order;
import com.test.sample.hirecooks.Models.users.User;
import com.test.sample.hirecooks.R;
import com.test.sample.hirecooks.Utils.SharedPrefManager;

import java.util.List;

public class OrdersAdapter extends RecyclerView.Adapter<OrdersAdapter.OrdersViewHolder> {
    private Context mCtx;
    private List<Order> orderList;
    User user = SharedPrefManager.getInstance(mCtx).getUser();
    public OrdersAdapter(Context mCtx, List<Order> orderList) {
        this.mCtx = mCtx;
        this.orderList = orderList;
    }

    @Override
    public OrdersAdapter.OrdersViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mCtx).inflate(R.layout.recyclerview_order, parent, false);
        return new OrdersAdapter.OrdersViewHolder(view);
    }

    @Override
    public void onBindViewHolder(OrdersAdapter.OrdersViewHolder holder, int position) {
        final Order order = orderList.get(position);
        if(order!=null){
            holder.itemName.setText(order.getProductName());
            holder.itemTotalAmount.setText("\u20B9 "+order.getProductTotalAmount());
            holder.item_count.setText("Quantity: "+order.getProductQuantity());
            holder.order_id.setText("Order ID: # "+order.getOrderId());
            holder.order_date_time.setText("Order Date Time: "+order.getOrderDateTime());
            holder.order_address.setText("Order Address: "+order.getOrderAddress());
            Picasso.with(mCtx).load(order.getProductImage()).into(holder.itemImage);
        }
    }

    @Override
    public int getItemCount() {
        return orderList==null?0:orderList.size();
    }

    class OrdersViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView itemName, itemTotalAmount, item_count, order_id, order_date_time,order_address;
        ImageView itemImage;

        public OrdersViewHolder(View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.item_name);
            itemTotalAmount = itemView.findViewById(R.id.order_totalAmount);
            itemImage = itemView.findViewById(R.id.product_thumb);
            item_count = itemView.findViewById(R.id.item_quantity);
            order_id = itemView.findViewById(R.id.order_id);
            order_date_time = itemView.findViewById(R.id.order_date_time);
            order_address = itemView.findViewById(R.id.order_address);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            
        }
    }
}
