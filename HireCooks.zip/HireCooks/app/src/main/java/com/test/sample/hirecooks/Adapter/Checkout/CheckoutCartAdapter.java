package com.test.sample.hirecooks.Adapter.Checkout;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.Gson;
import com.squareup.picasso.Picasso;
import com.test.sample.hirecooks.Models.Cart.Cart;
import com.test.sample.hirecooks.R;
import com.test.sample.hirecooks.RoomDatabase.LocalStorage.LocalStorage;

import java.util.List;


public class CheckoutCartAdapter extends RecyclerView.Adapter<CheckoutCartAdapter.MyViewHolder> {

    List<Cart> cartList;
    Context context;
    int SubTotal = 0, sellRate = 0, Quantity = 0;
    LocalStorage localStorage;
    Gson gson;


    public CheckoutCartAdapter(List<Cart> cartList, Context context) {
        this.cartList = cartList;
        this.context = context;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView;

        itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.checkout_cart_adapter, parent, false);


        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {

        final Cart cart = cartList.get(position);
        localStorage = new LocalStorage(context);
        gson = new Gson();
        if(cart!=null){
            if(cart.getWeight()!=null) {
                holder.attribute.setText("" + cart.getWeight());
            }else{
                holder.attribute.setText(1+" Piece");
            }
            holder.title.setText(cart.getName());
            sellRate = cart.getSellRate();
            Quantity = cart.getItemQuantity();
            holder.quantity.setText(""+Quantity);
            holder.price.setText(""+sellRate);
            SubTotal = (sellRate*Quantity);
            holder.plus.setVisibility(View.GONE);
            holder.minus.setVisibility(View.GONE);
            holder.delete.setVisibility(View.GONE);
            holder.subTotal.setText(""+SubTotal);
            Picasso.with(context).load(cart.getLink()).into(holder.imageView);
        }
    }

    @Override
    public int getItemCount() {

        return cartList==null?0:cartList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView title;
        TextView currency, price, quantity, attribute, addToCart, subTotal;
        Button plus, minus, delete;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.product_image);
            title = itemView.findViewById(R.id.product_title);
            quantity = itemView.findViewById(R.id.quantity);
            attribute = itemView.findViewById(R.id.product_attribute);
            plus = itemView.findViewById(R.id.quantity_plus);
            minus = itemView.findViewById(R.id.quantity_minus);
            delete = itemView.findViewById(R.id.cart_delete);
            subTotal = itemView.findViewById(R.id.sub_total);
            price = itemView.findViewById(R.id.product_price);
            currency = itemView.findViewById(R.id.product_currency);
        }
    }
}
