package com.test.sample.hirecooks.Services;

public class AuthServices {
}
