package com.test.sample.hirecooks.Models;

/**
 * Created by robert on 8/16/17.
 */

public class UploadObject {
    private String success;

    public UploadObject(String success) {
        this.success = success;
    }

    public String getSuccess() {
        return success;
    }
}