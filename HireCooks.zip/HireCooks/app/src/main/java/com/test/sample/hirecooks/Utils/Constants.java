package com.test.sample.hirecooks.Utils;

import com.test.sample.hirecooks.Models.SubCategory.Response.SubCategory;
import com.test.sample.hirecooks.Models.TokenResponse.TokenResult;
import com.test.sample.hirecooks.Models.users.Result;

import java.util.List;

public class Constants {

    public static String locationApiKey = "AIzaSyC-BYCFrpXUa4CI-H9fRqWEc0-I_ylk31k";
    public static Result TOKEN_DETAILS = null;
    public static Result CurrentUser = null;
    public static TokenResult CurrentToken = null;
    public static List<SubCategory> SUBCATEGORY = null;
    public static TokenResult TokenBYfirm_id = null;
    public static String weight = null;
}
