package com.test.sample.hirecooks.Adapter.Home;

public class NavigationItems {


	private String name;

	public NavigationItems( String name) {
		super();

		this.name = name;
	}

	public NavigationItems() {
		super();
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



}


