package com.test.sample.hirecooks.Activity.Home;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.test.sample.flowingdrawer_core.ElasticDrawer;
import com.test.sample.flowingdrawer_core.FlowingDrawer;
import com.test.sample.hirecooks.Activity.Cart.CartActivity;
import com.test.sample.hirecooks.ApiServiceCall.ApiClient;
import com.test.sample.hirecooks.BaseActivity;
import com.test.sample.hirecooks.Fragments.Home.HolderFragment;
import com.test.sample.hirecooks.Fragments.Home.HomeFragment;
import com.test.sample.hirecooks.Fragments.OrdersFragment;
import com.test.sample.hirecooks.Fragments.ProfileFragment;
import com.test.sample.hirecooks.Libraries.BedgeNotification.NotificationCountSetClass;
import com.test.sample.hirecooks.MenuListFragment;
import com.test.sample.hirecooks.Models.TokenResponse.TokenResult;
import com.test.sample.hirecooks.Models.users.User;
import com.test.sample.hirecooks.R;
import com.test.sample.hirecooks.Utils.Constants;
import com.test.sample.hirecooks.Utils.ProgressBarUtil;
import com.test.sample.hirecooks.Utils.SharedPrefManager;
import com.test.sample.hirecooks.WebApis.UserApi;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends BaseActivity {
    private FlowingDrawer mDrawer;
    private View appRoot;
    private Toolbar toolbar;
    private float mToolbarBarHeight;
    private ViewPager mViewPager;
    private List<Fragment> fragmentList;
    private BottomNavigationView mNavigationView;
    public static int notificationCountCart = 0;
    private User user;
    private UserApi mService;
    private String deviceId;
    private ProgressBarUtil progressBarUtil;

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        notificationCountCart = cartCount();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        user = SharedPrefManager.getInstance(this).getUser();
        initData();
        initViews();
        setupToolbar();
        setupFeed();
        setupMenu();
        getToken(user.getPhone(),user.getId(),user.getFirmId());
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @SuppressLint({"WrongConstant", "ClickableViewAccessibility"})
    private void initViews() {
        Fresco.initialize(this);
        progressBarUtil = new ProgressBarUtil(this);
        mDrawer = findViewById(R.id.drawerlayout);
        mDrawer.setTouchMode(ElasticDrawer.TOUCH_MODE_BEZEL);
        appRoot = findViewById(R.id.appRoot);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitleTextColor(Color.WHITE);
        //toolbar.setTitle("Welcome To HireCook");
        setSupportActionBar(toolbar);
        mNavigationView = (BottomNavigationView) findViewById(R.id.bye_burger);
        mViewPager = (ViewPager) findViewById(R.id.viewpager);


        mViewPager.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override public Fragment getItem(int position) {
                return fragmentList.get(position);
            }

            @Override public int getCount() {
                return fragmentList.size();
            }
        });

        mNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.navigation_home:
                                toolbar.setTitle("Home");
                                mViewPager.setCurrentItem(0);
                                return true;
                            case R.id.navigation_orders:
                                toolbar.setTitle("Orders");
                                mViewPager.setCurrentItem(1);
                                return true;
                            case R.id.navigation_profile:
                                toolbar.setTitle("Profile");
                                mViewPager.setCurrentItem(2);
                                return true;
                            case R.id.navigation_cart:
                                toolbar.setTitle("Cart");
                                mViewPager.setCurrentItem(3);
                                return true;
                        }
                        return false;
                    }
                });

        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(this,  new OnSuccessListener<InstanceIdResult>() {
            @Override
            public void onSuccess(InstanceIdResult instanceIdResult) {
                String newToken = instanceIdResult.getToken();
                Log.e("get token",newToken);
                System.out.println("get Token : "+newToken);
            }
        });
    }

    private void getToken(final String phone, int userId, String firm_id) {
        deviceId = Settings.Secure.getString(this.getContentResolver(), Settings.Secure.ANDROID_ID);
        Toast.makeText(this, deviceId, Toast.LENGTH_SHORT).show();

        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener(this,  new OnSuccessListener<InstanceIdResult>() {
            @Override
            public void onSuccess(InstanceIdResult instanceIdResult) {
                String newToken = instanceIdResult.getToken();
                Log.e("get token",newToken);
                if(!newToken.isEmpty()&&userId!=0){
                    updateTokenToServer(phone,newToken,0,deviceId,userId,firm_id);
                }else{
                    Toast.makeText(MainActivity.this,"Token Not Generated",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void updateTokenToServer(String phone, String newToken, int isServerToken, String deviceId, int userId, String firm_id) {
        mService = ApiClient.getClient().create(UserApi.class);
        Call<TokenResult> call = mService.updateToken(phone,newToken,deviceId,isServerToken,userId,firm_id);
        call.enqueue(new Callback<TokenResult>() {
            @Override
            public void onResponse(Call<TokenResult> call, Response<TokenResult> response) {
                int statusCode = response.code();
                if(statusCode==200&&response.body().getError()==false) {
                    Constants.CurrentToken = response.body();
                    progressBarUtil.hideProgress();
                    Toast.makeText(getApplicationContext(), response.body().getMessage(), Toast.LENGTH_LONG).show();
                    SharedPrefManager.getInstance(MainActivity.this).token(Constants.CurrentToken.getToken());
                }
                else{
                    Toast.makeText(MainActivity.this, "Failed due to :"+response.body().getMessage(), Toast.LENGTH_LONG).show();
                    Connection(MainActivity.this);
                }
            }

            @Override
            public void onFailure(Call<TokenResult> call, Throwable t) {
                progressBarUtil.hideProgress();
                Connection(MainActivity.this);

            }
        });
    }

    private void initData() {
        fragmentList = new ArrayList<>();
        fragmentList.add(HomeFragment.newInstance());
        fragmentList.add(OrdersFragment.newInstance());
        fragmentList.add(ProfileFragment.newInstance());
        fragmentList.add(HolderFragment.newInstance("Cart"));
    }

    protected void setupToolbar() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final TypedArray mTypedArray = getTheme().obtainStyledAttributes(new int[] { android.R.attr.actionBarSize });
        mToolbarBarHeight = mTypedArray.getDimension(0, 0);
        mTypedArray.recycle();
       // (findViewById(R.id.scrollView)).getViewTreeObserver().addOnScrollChangedListener(this);
        toolbar.setNavigationIcon(R.drawable.ic_menu_white);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawer.toggleMenu();
            }
        });
    }

    private void setupFeed() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this) {
            @Override
            protected int getExtraLayoutSpace(RecyclerView.State state) {
                return 300;
            }
        };
    }

    private void setupMenu() {
        FragmentManager fm = getSupportFragmentManager();
        MenuListFragment mMenuFragment = (MenuListFragment) fm.findFragmentById(R.id.id_container_menu);
        if (mMenuFragment == null) {
            mMenuFragment = new MenuListFragment();
            fm.beginTransaction().add(R.id.id_container_menu, mMenuFragment).commit();
        }
    }

    @Override
    public void onBackPressed() {
        if (mDrawer.isMenuVisible()){
            mDrawer.closeMenu();
            this.finish();
        } else {
            this.finish();
            super.onBackPressed();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater ( );
        menuInflater.inflate ( R.menu.cart_menu , menu );
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        // Get the notifications MenuItem and
        // its LayerDrawable (layer-list)
        MenuItem item = menu.findItem(R.id.action_cart);
        NotificationCountSetClass.setAddToCart(MainActivity.this, item,notificationCountCart);
        // force the ActionBar to relayout its MenuItems.
        // onCreateOptionsMenu(Menu) will be called again.
        invalidateOptionsMenu();
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id==android.R.id.home){
            this.finish();
        }else if ( id == R.id.action_cart ) {
            finish();
            startActivity(new Intent(MainActivity.this, CartActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onRestart(){
        notificationCountCart = cartCount();
        super.onRestart();
    }

    @Override
    protected void onStop() {
        //mDemoSlider.stopAutoCycle();
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean b = false;
        notificationCountCart = cartCount();
        Connection(this);
    }
}
